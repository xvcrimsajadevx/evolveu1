// function sum(a, b) {
// 	return 0;
// }

function sumAdd(a, b) {
  return Number(a) + Number(b);
}

function sumSub(a, b) {
  return Number(a) - Number(b);
}

function sumMult(a, b) {
  return Number(a) * Number(b);
}

function sumDiv(a, b) {
  return Number(a) / Number(b);
}

export default { sumAdd, sumSub, sumMult, sumDiv };
